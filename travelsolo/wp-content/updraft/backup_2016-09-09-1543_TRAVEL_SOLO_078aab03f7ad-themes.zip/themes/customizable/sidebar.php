<?php
/**
 * The Sidebar containing the main widget area
 */
	if ( is_active_sidebar( 'content-sidebar' ) ) : 
	
		 dynamic_sidebar( 'content-sidebar' ); 
		 
	endif; ?>

