<?php
/**
 * @package Planum
 */
?>
<div class="clearfix"></div>
<article id="post-0" class="no-tiles">
	<h1 class="entry-title"><?php _e( 'END', 'planum' ); ?></h1>
</article><!-- #post-0 -->
